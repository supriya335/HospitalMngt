CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

CREATE TABLE Patient (
    patientid INT PRIMARY KEY,
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    dateOfBirth DATE,
    gender VARCHAR(10),
    contactNumber VARCHAR(15),
    address VARCHAR(100)
);

CREATE TABLE Doctor (
    doctorid INT PRIMARY KEY,
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    specialization VARCHAR(50),
    contactNumber VARCHAR(15)
);

CREATE TABLE Appointment (
    appointmentid INT PRIMARY KEY,
    patientid INT,
    doctorid INT,
    appointmentDate DATE,
    description TEXT,
    FOREIGN KEY (patientid) REFERENCES Patient(patientid),
    FOREIGN KEY (doctorid) REFERENCES Doctor(doctorid)
);